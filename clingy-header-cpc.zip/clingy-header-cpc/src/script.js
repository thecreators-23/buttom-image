var scroll;
var title = document.getElementById("title");
var header = document.getElementById("header");
function getScrollPercent() {
    var h = document.documentElement, 
        b = document.body,
        st = 'scrollTop',
        sh = 'scrollHeight';
    return (h[st]||b[st]) / ((h[sh]||b[sh]) - h.clientHeight) * 100;
}

function check() {
  scroll = getScrollPercent();
  if (scroll > 0 && scroll < 15) {
    title.textContent = "Wait, where are you going?";
  } else if (scroll > 15 && scroll < 30) {
    title.textContent = "Don't worry, I know you'll be back.";
  } else if (scroll > 30 && scroll < 45) {
    title.textContent = "Stop scrolling, you meanie!";
  } else if (scroll > 45 && scroll < 60) {
    title.textContent = "If you stop scrolling, I'll give you sweets.";
  } else if (scroll > 60 && scroll < 75) {
    title.textContent = "Why do I exist, only to be scrolled away?";
  } else if (scroll > 75 && scroll <= 100) {
    title.textContent = "I'm ready, send me away";
  } else {
    title.textContent = "Boring header";
  }
  
  if (scroll > 75 && scroll <= 100) {
    header.style.top = Math.floor((-3.75 * (scroll - 75))).toString() + "px";
  } else {
    header.style.top = "0";
  }
  requestAnimationFrame(check);
}
check();